package com.example.context_menus

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
