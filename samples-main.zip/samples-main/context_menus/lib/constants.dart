const String kCodeUrl =
    'https://github.com/flutter/samples/blob/experimental/context_menus/lib';
