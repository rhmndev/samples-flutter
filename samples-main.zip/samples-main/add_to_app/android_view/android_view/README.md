# android_view

An example of an Android app that integrates a Flutter add-to-app module at a
view level.  For more information see [../README.md](../README.md).
