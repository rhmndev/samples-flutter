import UIKit

class BookCell: UITableViewCell {
  @IBOutlet weak var title: UILabel!
  @IBOutlet weak var subtitle: UILabel!
  @IBOutlet weak var byLine: UILabel!
  @IBOutlet weak var editButton: UIButton!
}
