# multiple_flutters_ios

This is an add-to-app sample that uses the Flutter Engine Group API to host
multiple instances of Flutter in an iOS app.

## Getting Started

```sh
cd ../multiple_flutters_module
flutter pub get
cd -
pod install
open MultipleFluttersIos.xcworkspace
# (build and run)
```

For more information see: [multiple_flutters/README.md](../README.md)
