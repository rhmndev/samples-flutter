package com.example.deeplink_store_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
