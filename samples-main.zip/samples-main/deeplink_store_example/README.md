# deeplink_store_example

A store app that includes three screen, ProductList, ProductDetails, and ProductCategoryList.
This app uses go_router to create routing table for all three screens. It also updates the project
parameters for Android and iOS to support deeplinks.

To learn more, visit <link TBD>.

## Getting Started

This app put a placeholder for Android Intent Filters and iOS Associated Domains. To use this
example, update them with your own web domain. 
