// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'models.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$IncrementImpl _$$IncrementImplFromJson(Map<String, dynamic> json) =>
    _$IncrementImpl(
      by: json['by'] as int,
    );

Map<String, dynamic> _$$IncrementImplToJson(_$IncrementImpl instance) =>
    <String, dynamic>{
      'by': instance.by,
    };

_$CountImpl _$$CountImplFromJson(Map<String, dynamic> json) => _$CountImpl(
      json['value'] as int,
    );

Map<String, dynamic> _$$CountImplToJson(_$CountImpl instance) =>
    <String, dynamic>{
      'value': instance.value,
    };
