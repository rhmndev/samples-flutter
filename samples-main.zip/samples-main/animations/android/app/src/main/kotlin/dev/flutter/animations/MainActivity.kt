package dev.flutter.animations

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
